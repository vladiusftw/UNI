-- task5
declare
    old_sal employee.salary%type;
    cursor c is select * from employee;
begin
    select salary into old_sal from employee where e# = 7839;
    old_sal := old_sal * 1.1;
    insert into transaction values('U',7839,0,old_sal,to_char(sysdate, 'MM'),to_char(sysdate, 'YYYY'),'',0,0);
    insert into transaction values('A',7839,0,0,0,0,'Dubai',12,2);
    
    for i in c loop
        insert into transaction values('P',i.e#,8,250,to_char(sysdate, 'MM'),to_char(sysdate, 'YYYY'),'',0,0);
    end loop;
end;