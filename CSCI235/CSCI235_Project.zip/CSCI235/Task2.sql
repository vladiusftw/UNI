-- Task2
create or replace function readTransactionTable return int -- returns number of errors that occured
as
    invalid_action_error exception; --1
    invalid_month_error exception; --2
    invalid_year_error exception; --3
    invalid_emp_error exception; --4
    invalid_city_error exception; --5
    invalid_street_error exception; --6
    invalid_bldg_error exception; --7
    invalid_days_error exception; --8
    invalid_extra_pay_error exception; --9
    
    cursor c is select * from transaction;
    
    num_errors int := 0;
    temp int := 0;
    temp_row employee%rowtype;
    
begin
    for i in c loop
        begin
            select count(e#) into temp from employee where e# = i.e#;
            if temp != 0 then
                if i.action = 'u' or i.action = 'U' then
                    if i.extra_pay >= 0 then
                        if i.month >= 1 and i.month <= 12 and i.month mod 1 = 0 then
                            if i.year <= to_char(sysdate, 'YYYY') and i.year >= 1992 and i.year mod 1 = 0 then -- we chose 1992 as lower bound because oracle pl sql was created at that year, so no possible value can be before that
                                select salary into temp from employee where e# = i.e#; -- get employee's salary
                                insert into logtable values(i.e#,i.action,0,'Old Salary:' || temp); -- put into logtable 
                                update employee set salary = i.extra_pay where e# = i.e#; -- update the employee
                            else raise invalid_year_error;
                            end if;
                        else raise invalid_month_error;
                        end if;
                    else raise invalid_extra_pay_error;
                    end if;
                elsif i.action = 'p' or i.action = 'P' then
                    if i.daysoff >= 0 and i.daysoff <= 30 and i.daysoff mod 1 = 0 then
                        if i.extra_pay >= 0 then
                             if i.month >= 1 and i.month <= 12 and i.month mod 1 = 0 then
                                if i.year <= to_char(sysdate, 'YYYY') and i.year >= 1992 and i.year mod 1 = 0 then -- we chose 1992 as lower bound because oracle pl sql was created at that year, so no possible value can be before that
                                    select salary into temp from employee where e# = i.e#; -- get employee's salary
                                    insert into salary_list values(i.e#,trunc((((temp/30)*(30-i.daysoff))+i.extra_pay),2),i.month,i.year); -- calculates salary 
                                    insert into logtable values(i.e#,i.action,0,'payment is:' || trunc((((temp/30)*(30-i.daysoff))+i.extra_pay),2)); -- put into logtable
                                else raise invalid_year_error;
                                end if;
                            else raise invalid_month_error;
                            end if;
                        else raise invalid_extra_pay_error;
                        end if;
                    else raise invalid_days_error;
                    end if;
                elsif i.action = 'd' or i.action = 'D' then
                    insert into logtable values(i.e#,i.action,0,'employee got deleted');
                    delete from employee where e# = i.e#;
                elsif i.action = 'a' or i.action = 'A' then
                    if regexp_like(i.city,'[[:digit:]]') = false then
                        if i.street# mod 1 = 0 and i.street# > 0 then
                            if i.bldg# mod 1 = 0 and i.bldg# > 0 then 
                                select * into temp_row from employee where e# = i.e#;
                                insert into logtable values(i.e#,i.action,0,'Old Address:' || temp_row.city || ', ' || temp_row.street# || ', ' || temp_row.bldg#);
                                update employee set city = i.city, street# = i.street#, bldg# = i.bldg# where e# = i.e#;
                            else raise invalid_bldg_error;
                            end if;
                        else raise invalid_street_error;
                        end if;
                    else raise invalid_city_error;
                    end if;
                else raise invalid_action_error;
                end if;
            
            else raise invalid_emp_error;
            end if;
        
        exception 
            when invalid_action_error then
                insert into logtable values(i.e#,i.action,1,'invalid action');
                num_errors := num_errors + 1;
            when invalid_month_error then
                 insert into logtable values(i.e#,i.action,2,'invalid month');
                 num_errors := num_errors + 1;
            when invalid_year_error then
                insert into logtable values(i.e#,i.action,3,'invalid year');
                num_errors := num_errors + 1;
            when invalid_emp_error then 
                insert into logtable values(i.e#,i.action,4,'invalid emp#');
                num_errors := num_errors + 1;
            when invalid_city_error then
                insert into logtable values(i.e#,i.action,5,'invalid city');
                num_errors := num_errors + 1;
            when invalid_street_error then 
                insert into logtable values(i.e#,i.action,6,'invalid street#');
                num_errors := num_errors + 1;
            when invalid_bldg_error then
                insert into logtable values(i.e#,i.action,7,'invalid building#');
                num_errors := num_errors + 1;
            when invalid_days_error then
                insert into logtable values(i.e#,i.action,8,'invalid days off');
                num_errors := num_errors + 1;
            when invalid_extra_pay_error then
                 insert into logtable values(i.e#,i.action,9,'invalid extra pay');
                 num_errors := num_errors + 1;
        end;
    end loop;
    delete from transaction;
    return num_errors;
end;