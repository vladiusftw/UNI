-- running task2
begin
    dbms_output.put_line('Number of errors:' || readTransactionTable);
end;