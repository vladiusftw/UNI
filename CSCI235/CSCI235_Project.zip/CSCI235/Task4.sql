-- Task4
create or replace trigger show_employee after update on employee
for each row
begin
    dbms_output.put_line('E#:' || :old.e#);
    if :old.salary != :new.salary then
        dbms_output.put_line('Old Salary:' || :old.salary);
        dbms_output.put_line('New Salary:' || :new.salary);
        insert into logtable values(:new.e#,'X','-1','Old Salary:' || :old.salary || ', New Salary:' || :new.salary);
    else
        dbms_output.put_line('Old Address(City, Street#, BLDG#):' || :old.city || ', ' || :old.street# || ', ' || :old.bldg#);
        dbms_output.put_line('New Address(City, Street#, BLDG#):' || :new.city || ', ' || :new.street# || ', ' || :new.bldg#);
        insert into logtable values(:new.e#,'X','-1','Old Address(City, Street#, BLDG#):' || :old.city || ', ' || :old.street# 
        || ', ' || :old.bldg# || ', New Address(City, Street#, BLDG#):' || :new.city || ', ' || :new.street# || ', ' || :new.bldg#);
    end if;
end;