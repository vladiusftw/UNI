-- Task3
create or replace trigger show_salary after insert on salary_list
for each row
begin
dbms_output.put_line('E#:' || :new.e# || ', Payment:' || :new.payment || ', Date(MM/YYYY):' || :new.month || '/' || :new.year);
end;