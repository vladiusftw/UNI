set serveroutput on;

CREATE TABLE Transaction( 
ACTION CHAR(1),
E# NUMBER(4),
DAYSOFF NUMBER(2),
EXTRA_PAY NUMBER(9,2),
MONTH NUMBER(2),
YEAR NUMBER(4),
CITY VARCHAR(13),
STREET#	NUMBER(3),
BLDG# NUMBER(4)
);

CREATE TABLE Salary_List( 
E# NUMBER(4),
PAYMENT NUMBER(7,2),
MONTH NUMBER(2),
YEAR NUMBER(4)
);
    
CREATE TABLE EMPLOYEE(
E# 	NUMBER(4),
ENAME VARCHAR2(10),
MANAGER# NUMBER(4),
HIREDATE DATE,
SALARY NUMBER(9,2),
COMM NUMBER(7,2),
DNAME VARCHAR2(14),
CITY VARCHAR(13),
STREET#	NUMBER(3),
BLDG#	NUMBER(4),
LEVEL#	NUMBER(2),
PRIMARY KEY(E#));

CREATE TABLE LOGTABLE(
E# number(4),
ACTION CHAR(1),
ERROR_CODE NUMBER(2),
ERROR_DESC VARCHAR(150)
);
    
INSERT INTO EMPLOYEE VALUES (7839,'KING',NULL,'17-NOV-90',5000,NULL,'RESEARCH', 'NEW YORK', 30, 123, 99);
INSERT INTO EMPLOYEE VALUES (7566,'JONES',7839,'2-APR-81',2975,NULL,'ACCOUNTING','NEW YORK', 30, 123, 99);
INSERT INTO EMPLOYEE VALUES (7698,'BLAKE',7839,'1-MAY-81',2850,NULL,'OPERATIONS','BOSTON', 45, 34, 10);
INSERT INTO EMPLOYEE VALUES (7782,'CLARK',7839,'9-JUN-81',2450,NULL,'ACCOUNTING','NEW YORK', 30, 123, 99);
INSERT INTO EMPLOYEE VALUES (7788,'SCOTT',7566,'09-DEC-82',3000,NULL,'RESEARCH','NEW YORK', 30, 123, 99);
INSERT INTO EMPLOYEE VALUES (7902,'FORD',7566,'3-DEC-81',3000,NULL,'OPERATIONS','BOSTON', 45, 34, 10);
INSERT INTO EMPLOYEE VALUES (7499,'ALLEN',7698,'20-FEB-81',1600,300,'SALES','LOS ANGELES', 35, 1, 99);
INSERT INTO EMPLOYEE VALUES (7466,'ALLEN',7698,'10-JUN-76',2000,335,'SALES','BOSTON', 29, 999, 34);
INSERT INTO EMPLOYEE VALUES (7498,'ALLEN',7698,'20-FEB-81',1600,300,'SALES','LOS ANGELES', 35, 1, 99);
INSERT INTO EMPLOYEE VALUES (7521,'WARD',7698,'22-FEB-81',1250,500,'','CHICAGO', 34, 1, 90);
INSERT INTO EMPLOYEE VALUES (7654,'MARTIN',7698,'28-SEP-81',1250,1400,'SALES','DALLAS', 34, 1, 6);
INSERT INTO EMPLOYEE VALUES (7844,'TURNER',7698,'8-SEP-81',1500,100,'SALES','NEW YORK', 30, 123, 99);
INSERT INTO EMPLOYEE VALUES (7234,'BONAPARTE',7466,'8-MAY-66',1500,100,'SALES','PARIS', 19, 77, 34);
INSERT INTO EMPLOYEE VALUES (7235,'D''ARC',7466,'20-FEB-78',2200,300,'SALES','PARIS', 19, 77, 34);
INSERT INTO EMPLOYEE VALUES (7900,'JAMES',7698,'3-DEC-81',950,NULL,'ACCOUNTING','NEW YORK', 30, 123, 99);
INSERT INTO EMPLOYEE VALUES (7876,'ADAMS',7788,'12-JAN-83',1100,NULL,'ACCOUNTING','NEW YORK', 30, 123, 99);
INSERT INTO EMPLOYEE VALUES (7369,'SMITH',7902,'17-DEC-80',800,NULL,'OPERATIONS','BOSTON', 45, 34, 10);
INSERT INTO EMPLOYEE VALUES (7811,'HILL',7876,'23-DEC-80',1800,NULL,'TRANSPORT', 'NEW YORK', 34, 56, 23);
INSERT INTO EMPLOYEE VALUES (7812,'LAUDA',7521,'22-JUN-50',1100,500,'TRANSPORT', 'NEW YORK', 34, 56, 23);
INSERT INTO EMPLOYEE VALUES (7813,'BERGER',7654,'23-APR-67',1200,300,'TRANSPORT', 'NEW YORK', 34, 56, 23);




-- Task2
create or replace function readTransactionTable return int -- returns number of errors that occured
as
    invalid_action_error exception; --1
    invalid_month_error exception; --2
    invalid_year_error exception; --3
    invalid_emp_error exception; --4
    invalid_city_error exception; --5
    invalid_street_error exception; --6
    invalid_bldg_error exception; --7
    invalid_days_error exception; --8
    invalid_extra_pay_error exception; --9
    
    cursor c is select * from transaction;
    
    num_errors int := 0;
    temp int := 0;
    temp_row employee%rowtype;
    
begin
    for i in c loop
        begin
            select count(e#) into temp from employee where e# = i.e#;
            if temp != 0 then
                if i.action = 'u' or i.action = 'U' then
                    if i.extra_pay >= 0 then
                        if i.month >= 1 and i.month <= 12 and i.month mod 1 = 0 then
                            if i.year <= to_char(sysdate, 'YYYY') and i.year >= 1992 and i.year mod 1 = 0 then -- we chose 1992 as lower bound because oracle pl sql was created at that year, so no possible value can be before that
                                select salary into temp from employee where e# = i.e#; -- get employee's salary
                                insert into logtable values(i.e#,i.action,0,'Old Salary:' || temp); -- put into logtable 
                                update employee set salary = i.extra_pay where e# = i.e#; -- update the employee
                            else raise invalid_year_error;
                            end if;
                        else raise invalid_month_error;
                        end if;
                    else raise invalid_extra_pay_error;
                    end if;
                elsif i.action = 'p' or i.action = 'P' then
                    if i.daysoff >= 0 and i.daysoff <= 30 and i.daysoff mod 1 = 0 then
                        if i.extra_pay >= 0 then
                             if i.month >= 1 and i.month <= 12 and i.month mod 1 = 0 then
                                if i.year <= to_char(sysdate, 'YYYY') and i.year >= 1992 and i.year mod 1 = 0 then -- we chose 1992 as lower bound because oracle pl sql was created at that year, so no possible value can be before that
                                    select salary into temp from employee where e# = i.e#; -- get employee's salary
                                    insert into salary_list values(i.e#,trunc((((temp/30)*(30-i.daysoff))+i.extra_pay),2),i.month,i.year); -- calculates salary 
                                    insert into logtable values(i.e#,i.action,0,'payment is:' || trunc((((temp/30)*(30-i.daysoff))+i.extra_pay),2)); -- put into logtable
                                else raise invalid_year_error;
                                end if;
                            else raise invalid_month_error;
                            end if;
                        else raise invalid_extra_pay_error;
                        end if;
                    else raise invalid_days_error;
                    end if;
                elsif i.action = 'd' or i.action = 'D' then
                    insert into logtable values(i.e#,i.action,0,'employee got deleted');
                    delete from employee where e# = i.e#;
                elsif i.action = 'a' or i.action = 'A' then
                    if regexp_like(i.city,'[[:digit:]]') = false then
                        if i.street# mod 1 = 0 and i.street# > 0 then
                            if i.bldg# mod 1 = 0 and i.bldg# > 0 then 
                                select * into temp_row from employee where e# = i.e#;
                                insert into logtable values(i.e#,i.action,0,'Old Address:' || temp_row.city || ', ' || temp_row.street# || ', ' || temp_row.bldg#);
                                update employee set city = i.city, street# = i.street#, bldg# = i.bldg# where e# = i.e#;
                            else raise invalid_bldg_error;
                            end if;
                        else raise invalid_street_error;
                        end if;
                    else raise invalid_city_error;
                    end if;
                else raise invalid_action_error;
                end if;
            
            else raise invalid_emp_error;
            end if;
        
        exception 
            when invalid_action_error then
                insert into logtable values(i.e#,i.action,1,'invalid action');
                num_errors := num_errors + 1;
            when invalid_month_error then
                 insert into logtable values(i.e#,i.action,2,'invalid month');
                 num_errors := num_errors + 1;
            when invalid_year_error then
                insert into logtable values(i.e#,i.action,3,'invalid year');
                num_errors := num_errors + 1;
            when invalid_emp_error then 
                insert into logtable values(i.e#,i.action,4,'invalid emp#');
                num_errors := num_errors + 1;
            when invalid_city_error then
                insert into logtable values(i.e#,i.action,5,'invalid city');
                num_errors := num_errors + 1;
            when invalid_street_error then 
                insert into logtable values(i.e#,i.action,6,'invalid street#');
                num_errors := num_errors + 1;
            when invalid_bldg_error then
                insert into logtable values(i.e#,i.action,7,'invalid building#');
                num_errors := num_errors + 1;
            when invalid_days_error then
                insert into logtable values(i.e#,i.action,8,'invalid days off');
                num_errors := num_errors + 1;
            when invalid_extra_pay_error then
                 insert into logtable values(i.e#,i.action,9,'invalid extra pay');
                 num_errors := num_errors + 1;
        end;
    end loop;
    delete from transaction;
    return num_errors;
end;

-- Task3
create or replace trigger show_salary after insert on salary_list
for each row
begin
dbms_output.put_line('E#:' || :new.e# || ', Payment:' || :new.payment || ', Date(MM/YYYY):' || :new.month || '/' || :new.year);
end;

-- Task4
create or replace trigger show_employee after update on employee
for each row
begin
    dbms_output.put_line('E#:' || :old.e#);
    if :old.salary != :new.salary then
        dbms_output.put_line('Old Salary:' || :old.salary);
        dbms_output.put_line('New Salary:' || :new.salary);
        insert into logtable values(:new.e#,'X','-1','Old Salary:' || :old.salary || ', New Salary:' || :new.salary);
    else
        dbms_output.put_line('Old Address(City, Street#, BLDG#):' || :old.city || ', ' || :old.street# || ', ' || :old.bldg#);
        dbms_output.put_line('New Address(City, Street#, BLDG#):' || :new.city || ', ' || :new.street# || ', ' || :new.bldg#);
        insert into logtable values(:new.e#,'X','-1','Old Address(City, Street#, BLDG#):' || :old.city || ', ' || :old.street# 
        || ', ' || :old.bldg# || ', New Address(City, Street#, BLDG#):' || :new.city || ', ' || :new.street# || ', ' || :new.bldg#);
    end if;
end;

-- task5
declare
    old_sal employee.salary%type;
    cursor c is select * from employee;
begin
    select salary into old_sal from employee where e# = 7839;
    old_sal := old_sal * 1.1;
    insert into transaction values('U',7839,0,old_sal,to_char(sysdate, 'MM'),to_char(sysdate, 'YYYY'),'',0,0);
    insert into transaction values('A',7839,0,0,0,0,'Dubai',12,2);
    
    for i in c loop
        insert into transaction values('P',i.e#,8,250,to_char(sysdate, 'MM'),to_char(sysdate, 'YYYY'),'',0,0);
    end loop;
end;

-- Task6
INSERT INTO TRANSACTION VALUES ('U',7839,5,105.33,11,2021,'Dubai', 502, 8016);

INSERT INTO TRANSACTION VALUES ('D',7698,6,150.33,10,2021,'Sharjah', 11.83, 7123);

INSERT INTO TRANSACTION VALUES ('A',8121,7,130.71,12,-2022,'Alain', 302, 1889);

INSERT INTO TRANSACTION VALUES ('U',7813,2,247.28,9.5,2022,'AbuDhabi', 198, 1286);

INSERT INTO TRANSACTION VALUES ('P',7566,1,-205.73,08,2021,'Dubai', 502, 1316);

INSERT INTO TRANSACTION VALUES ('U',7782,9.5,337.45,05,2022,'Fujairah', -111, 2106);

INSERT INTO TRANSACTION VALUES ('A',7499,12,436.32,03,2021, 5667, 304, 7215);

INSERT INTO TRANSACTION VALUES ('U',7521,09,966.41,07,2022, 'AbuDhabi', 233, 4256);

INSERT INTO TRANSACTION VALUES ('D',7654,22,831.73,02,2021, 'Sharjah', 906, 9595);

INSERT INTO TRANSACTION VALUES ('D',7235,19,545.69,13,2021, 'Sharjah', 125, 8489);

INSERT INTO TRANSACTION VALUES ('U',1145,23,119.82,10,2020, 'Alain', 115, 5295);

INSERT INTO TRANSACTION VALUES ('U',7813,32,791.97,01,2022, -78951, 541, 1518);

INSERT INTO TRANSACTION VALUES ('A',7369,02,369.13,08,2022, 'Dubai', 894, -7842);

INSERT INTO TRANSACTION VALUES ('U',1256,05,124.29,07,20, 'AbuDhabi', 659, 1249);

INSERT INTO TRANSACTION VALUES ('P',7876,11,301.99,04,2021, 'Fujairah', 999, 9789);

INSERT INTO TRANSACTION VALUES ('U',7844,06,219.22,12,2022, 'Dubai', 635, 5213);

INSERT INTO TRANSACTION VALUES ('D',7900,12,111.95,11,2021, 'Sharjah', 897, 8948);

INSERT INTO TRANSACTION VALUES ('P',7235,9.5,228.54,09,2022, 'Dubai', 168, 5792);

INSERT INTO TRANSACTION VALUES ('Q',7876,9,158.54,09,2022,'Fujairah', 237, 8416);

INSERT INTO TRANSACTION VALUES ('U',7876,9,789.47,09,2021,'AbuDhabi', -237, 8416);

INSERT INTO TRANSACTION VALUES ('U',7839,17,999.99,14,2021,'AbuDhabi', 586, 7944);

INSERT INTO TRANSACTION VALUES ('U',7788,26,567.88,05,2028,'AlAin', 777, 9999);

INSERT INTO TRANSACTION VALUES ('A',7902,12,123.20,07,2022, 'Fujairah', 256, 4569);


-- running task2
begin
    dbms_output.put_line('Number of errors:' || readTransactionTable);
end;































































